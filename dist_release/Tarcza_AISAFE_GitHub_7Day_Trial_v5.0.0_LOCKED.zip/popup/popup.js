/* 🔒 AISAFE™ IP COMPILER v5.5 ANTI-AI-AGENT FORTRESS | COPYRIGHT (C) 2026 BRAIN IN A HAT LIMITED | ECOSYSTEM EDGEMIND & THEAILAWS.COM | TARCZA AISAFE v5.5 PROPRIETARY INTELLECTUAL PROPERTY | ALL RIGHTS RESERVED | FILE: popup.js */
(function(){
const _0x_c="COPYRIGHT (C) 2026 BRAIN IN A HAT LIMITED | ECOSYSTEM EDGEMIND & THEAILAWS.COM | TARCZA AISAFE v5.5 PROPRIETARY INTELLECTUAL PROPERTY | ALL RIGHTS RESERVED";
let _0x_s=0;for(let _i=0;_i<_0x_c.length;_i++){_0x_s=(_0x_s+_0x_c.charCodeAt(_i)*((_i%17)+1))%9999991;}
if(_0x_s!==93085){throw new Error('[AISAFE COPYRIGHT VIOLATION] IP Seal Tampered');}
const _0x_decoy_canary={_trap:'AISAFE_HONEY_DECOY_ACTIVE',_weights:[0x1337,0xdead,0xbeef,0xcafe]};
if(typeof Function.prototype.toString==='function'&&!Function.prototype.toString.toString().includes('[native code]')){console.warn(_0x_decoy_canary._trap);return;}
})();
const ADDON_CHANNEL = "GITHUB_7DAY_TRIAL";
const DEFAULT_TIER = "TIER_1_TRIAL";
const I18N_PACKS = {"pl": {"lang_label": "🇵🇱 Polski (PL)", "app_name": "Tarcza AISAFE™ v5.0 — Suwerenna Ochrona AI", "app_desc": "18-Filarowa Tarcza Kognitywna AI: Maskowanie PII Data Cloak, Granica SSRF Air-Gap, Token Woli Człowieka (PoHV) i Licencje PQC.", "status_active": "OCHRONA KOGNITYWNA AKTYWNA", "pillars_prefix": "Aktywne Filary:", "inst_id_lbl": "ID Instalacji:", "hwid_lbl": "HWID Jednostki:", "cnt_threats": "Zagrożenia", "cnt_pii": "PII Maskowane", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "Tokeny PoHV", "sec_buy_title": "🛒 Wybór Wersji Licencyjnej (1 z 4) i Zakup ('KUP')", "select_tier_lbl": "Wybierz 1 z 4 Wersji Licencyjnych:", "email_lbl": "E-mail Transakcji (Na ten adres serwer wyśle klucz):", "server_lbl": "Serwer Generowania Klucza Licencji:", "btn_buy": "🛒 KUP — Wyślij Zapytanie i Odbierz Klucz na E-mail", "activate_lbl": "🔑 Posiadasz Klucz z E-maila? Wklej i Aktywuj:", "btn_activate": "Aktywuj"}, "en": {"lang_label": "🇬🇧 English (EN)", "app_name": "AISAFE™ Shield v6.0 — Sovereign AI Protection", "app_desc": "19-Pillar Cognitive AI Firewall: Zero-Gap PII Data Cloak, SSRF Air-Gap, Proof-of-Human-Volition (PoHV) & Post-Quantum Licensing.", "status_active": "COGNITIVE PROTECTION ACTIVE", "pillars_prefix": "Active Pillars:", "inst_id_lbl": "Installation ID:", "hwid_lbl": "Unit HWID:", "cnt_threats": "Threats Blocked", "cnt_pii": "PII Masked", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "PoHV Tokens", "sec_buy_title": "🛒 Select License Version (1 of 4) & Purchase ('BUY')", "select_tier_lbl": "Choose 1 of 4 Licensing Versions:", "email_lbl": "Transaction Email (Server sends license key here):", "server_lbl": "License Key Generation Server:", "btn_buy": "🛒 BUY — Send Request & Receive Key via Email", "activate_lbl": "🔑 Have an Email License Key? Paste & Activate:", "btn_activate": "Activate"}, "de": {"lang_label": "🇩🇪 Deutsch (DE)", "app_name": "AISAFE Schild™ v5.0 — Souveräner KI-Schutz", "app_desc": "18-Säulen KI-Sicherheits-Firewall: PII Data Cloak, SSRF Air-Gap, Proof-of-Human-Volition (PoHV) & Post-Quanten-Lizenzen.", "status_active": "KOGNITIVER SCHUTZ AKTIV", "pillars_prefix": "Aktive Säulen:", "inst_id_lbl": "Installations-ID:", "hwid_lbl": "Geräte-HWID:", "cnt_threats": "Bedrohungen", "cnt_pii": "PII Maskiert", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "PoHV Token", "sec_buy_title": "🛒 Lizenzversion wählen (1 von 4) & Kaufen ('KUP')", "select_tier_lbl": "Wählen Sie 1 von 4 Lizenzversionen:", "email_lbl": "Transaktions-E-Mail (Für den Lizenzschlüssel-Versand):", "server_lbl": "Lizenzschlüssel-Generierungsserver:", "btn_buy": "🛒 KAUFEN — Anfrage senden & Schlüssel per E-Mail erhalten", "activate_lbl": "🔑 Lizenzschlüssel erhalten? Einfügen & Aktivieren:", "btn_activate": "Aktivieren"}, "es": {"lang_label": "🇪🇸 Español (ES)", "app_name": "Escudo AISAFE™ v5.0 — Protección Soberana de IA", "app_desc": "Cortafuegos Cognitivo de IA de 18 Pilares: Data Cloak PII, SSRF Air-Gap, Prueba de Voluntad Humana (PoHV) y Licencias PQC.", "status_active": "PROTECCIÓN COGNITIVA ACTIVA", "pillars_prefix": "Pilares Activos:", "inst_id_lbl": "ID de Instalación:", "hwid_lbl": "HWID de Unidad:", "cnt_threats": "Amenazas", "cnt_pii": "PII Ocultos", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "Tokens PoHV", "sec_buy_title": "🛒 Selección de Licencia (1 de 4) y Compra ('KUP')", "select_tier_lbl": "Elija 1 de las 4 Versiones de Licencia:", "email_lbl": "Correo de Transacción (Recibirá la clave por e-mail):", "server_lbl": "Servidor Generador de Licencias:", "btn_buy": "🛒 COMPRAR — Enviar Solicitud y Recibir Clave por E-mail", "activate_lbl": "🔑 ¿Tiene Clave de E-mail? Pegar y Activar:", "btn_activate": "Activar"}, "fr": {"lang_label": "🇫🇷 Français (FR)", "app_name": "Bouclier AISAFE™ v5.0 — Protection IA Souveraine", "app_desc": "Pare-feu Cognitif IA à 18 Piliers : Masquage PII Data Cloak, SSRF Air-Gap, Preuve de Volonté Humaine (PoHV) et Licences PQC.", "status_active": "PROTECTION COGNITIVE ACTIVE", "pillars_prefix": "Piliers Actifs :", "inst_id_lbl": "ID d'Installation :", "hwid_lbl": "HWID Unité :", "cnt_threats": "Menaces", "cnt_pii": "PII Masqués", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "Jetons PoHV", "sec_buy_title": "🛒 Choix de Licence (1 sur 4) et Achat ('KUP')", "select_tier_lbl": "Choisissez 1 des 4 Versions de Licence :", "email_lbl": "E-mail de Transaction (Réception de la clé) :", "server_lbl": "Serveur de Génération de Clés :", "btn_buy": "🛒 ACHETER — Envoyer la Demande et Recevoir la Clé par E-mail", "activate_lbl": "🔑 Clé reçue par E-mail ? Coller et Activer :", "btn_activate": "Activer"}, "it": {"lang_label": "🇮🇹 Italiano (IT)", "app_name": "Scudo AISAFE™ v5.0 — Protezione IA Sovrana", "app_desc": "Firewall Cognitivo IA a 18 Pilastri: Mascheramento PII Data Cloak, SSRF Air-Gap, Prova di Volontà Umana (PoHV) e Licenze PQC.", "status_active": "PROTEZIONE COGNITIVA ATTIVA", "pillars_prefix": "Pilastri Attivi:", "inst_id_lbl": "ID Installazione:", "hwid_lbl": "HWID Unità:", "cnt_threats": "Minacce", "cnt_pii": "PII Mascherati", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "Token PoHV", "sec_buy_title": "🛒 Selezione Licenza (1 di 4) e Acquisto ('KUP')", "select_tier_lbl": "Scegli 1 delle 4 Versioni di Licenza:", "email_lbl": "E-mail Transazione (Ricezione chiave su e-mail):", "server_lbl": "Server Generazione Chiavi:", "btn_buy": "🛒 ACQUISTA — Invia Richiesta e Ricevi Chiave via E-mail", "activate_lbl": "🔑 Hai la Chiave E-mail? Incolla e Attiva:", "btn_activate": "Attiva"}, "nl": {"lang_label": "🇳🇱 Nederlands (NL)", "app_name": "AISAFE Schild™ v5.0 — Soevereine AI-Bescherming", "app_desc": "18-Pijler Cognitieve AI-Firewall: PII Data Cloak, SSRF Air-Gap, Proof-of-Human-Volition (PoHV) & Post-Quantum Licenties.", "status_active": "COGNITIEVE BESCHERMING ACTIEF", "pillars_prefix": "Actieve Pijlers:", "inst_id_lbl": "Installatie-ID:", "hwid_lbl": "Eenheid HWID:", "cnt_threats": "Bedreigingen", "cnt_pii": "PII Gemaskeerd", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "PoHV Tokens", "sec_buy_title": "🛒 Kies Licentieversie (1 van 4) & Koop ('KUP')", "select_tier_lbl": "Kies 1 van de 4 Licentieversies:", "email_lbl": "Transactie E-mail (Voor ontvangst licentiesleutel):", "server_lbl": "Licentiesleutel Server:", "btn_buy": "🛒 KOPEN — Verzoek Verzenden & Sleutel per E-mail Ontvangen", "activate_lbl": "🔑 Sleutel ontvangen? Plakken & Activeren:", "btn_activate": "Activeren"}, "pt": {"lang_label": "🇵🇹 Português (PT)", "app_name": "Escudo AISAFE™ v5.0 — Proteção Soberana de IA", "app_desc": "Firewall Cognitivo de IA de 18 Pilares: Data Cloak PII, SSRF Air-Gap, Prova de Vontade Humana (PoHV) e Licenças PQC.", "status_active": "PROTEÇÃO COGNITIVA ATIVA", "pillars_prefix": "Pilares Ativos:", "inst_id_lbl": "ID de Instalação:", "hwid_lbl": "HWID da Unidade:", "cnt_threats": "Ameaças", "cnt_pii": "PII Mascarados", "cnt_ssrf": "SSRF Air-Gap", "cnt_pohv": "Tokens PoHV", "sec_buy_title": "🛒 Escolha a Versão de Licença (1 de 4) e Compre ('KUP')", "select_tier_lbl": "Escolha 1 das 4 Versões de Licença:", "email_lbl": "E-mail da Transação (Receberá a chave por e-mail):", "server_lbl": "Servidor de Geração de Chaves:", "btn_buy": "🛒 COMPRAR — Enviar Pedido e Receber Chave por E-mail", "activate_lbl": "🔑 Possui Chave do E-mail? Colar e Ativar:", "btn_activate": "Ativar"}};
const TIER_LABELS = {
"TIER_1_TRIAL": { badge: "Tier 1: 7-Day Trial", pillars: "6 / 18 (Managed Trust)" },
"TIER_2_HOME": { badge: "Tier 2: Home Shield", pillars: "10 / 18 (Dual Open+Closed)" },
"TIER_3_FORTRESS": { badge: "Tier 3: AI Fortress", pillars: "14 / 18 (EdgeMind Standard)" },
"TIER_4_ENTERPRISE": { badge: "Tier 4: Enterprise", pillars: "18 / 18 (Assured Trust + ONNX Veto)" }
};
function applyLanguage(langCode) {
const pack = I18N_PACKS[langCode] || I18N_PACKS["pl"];
document.getElementById("trust-level").innerText = pack.status_active;
document.getElementById("lbl-inst-id").innerText = pack.inst_id_lbl;
document.getElementById("lbl-hwid").innerText = pack.hwid_lbl;
document.getElementById("lbl-cnt-threats").innerText = pack.cnt_threats;
document.getElementById("lbl-cnt-pii").innerText = pack.cnt_pii;
document.getElementById("lbl-cnt-ssrf").innerText = pack.cnt_ssrf;
document.getElementById("lbl-cnt-pohv").innerText = pack.cnt_pohv;
document.getElementById("lbl-sec-buy").innerText = pack.sec_buy_title;
document.getElementById("lbl-select-tier").innerText = pack.select_tier_lbl;
document.getElementById("lbl-email").innerText = pack.email_lbl;
document.getElementById("lbl-server").innerText = pack.server_lbl;
document.getElementById("btn-buy-license").innerText = pack.btn_buy;
document.getElementById("lbl-activate").innerText = pack.activate_lbl;
document.getElementById("btn-activate-key").innerText = pack.btn_activate;
}
document.addEventListener("DOMContentLoaded", () => {
chrome.storage.local.get("aisafe_state", (res) => {
let st = res.aisafe_state || {};
let tier = st.tier || DEFAULT_TIER;
let lang = st.lang || "pl";
let info = TIER_LABELS[tier] || TIER_LABELS["TIER_1_TRIAL"];
document.getElementById("lang-select").value = lang;
applyLanguage(lang);
document.getElementById("blocked-count").innerText = st.threats_blocked_count || 0;
document.getElementById("pii-count").innerText = st.pii_redacted_count || 0;
document.getElementById("ssrf-count").innerText = st.ssrf_blocked_count || 0;
document.getElementById("pohv-count").innerText = st.pohv_volition_trips || 0;
document.getElementById("tier-badge").innerText = info.badge;
const pack = I18N_PACKS[lang] || I18N_PACKS["pl"];
document.getElementById("pillars-info").innerText = pack.pillars_prefix + " " + info.pillars;
document.getElementById("inst-id").innerText = st.installation_id || "INST-AISAFE-UNIT-01";
document.getElementById("unit-hwid").innerText = (st.hwid || "a8f9c2e1b4d7091234ef98a1c3b5d7e9").substring(0, 26) + "...";
});
document.getElementById("lang-select").addEventListener("change", (e) => {
const chosenLang = e.target.value;
applyLanguage(chosenLang);
chrome.storage.local.get("aisafe_state", (res) => {
let st = res.aisafe_state || {};
st.lang = chosenLang;
chrome.storage.local.set({ aisafe_state: st });
});
});
document.getElementById("btn-buy-license").addEventListener("click", async () => {
const selectedTier = document.getElementById("tier-select").value;
const email = document.getElementById("purchase-email").value.trim();
const serverUrl = document.getElementById("server-url").value.trim().replace(/\/+$/, "");
const statusBox = document.getElementById("purchase-status");
if (!email || !email.includes("@")) {
statusBox.style.color = "#ef4444";
statusBox.innerText = "⚠️ Podaj prawidłowy adres e-mail do wysyłki klucza!";
return;
}
statusBox.style.color = "#38bdf8";
statusBox.innerText = "⏳ Wysyłanie zapytania z instalacji do serwera licencyjnego...";
chrome.storage.local.get("aisafe_state", async (res) => {
let st = res.aisafe_state || {};
let payload = {
installation_id: st.installation_id || "INST-AISAFE-ADDON",
hwid: st.hwid || "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
tier: selectedTier,
billing_cycle: "ANNUAL",
channel: ADDON_CHANNEL,
customer_name: email.split("@")[0],
email: email
};
try {
const response = await fetch(serverUrl + "/api/v1/purchase-license", {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify(payload)
});
const data = await response.json();
if (response.ok && data.serial_code) {
statusBox.style.color = "#10b981";
statusBox.innerText = "✅ Wygenerowano klucz i wysłano na " + email + "! Klucz: " + data.serial_code;
document.getElementById("license-key-input").value = data.serial_code;
} else {
statusBox.style.color = "#ef4444";
statusBox.innerText = "❌ Błąd serwera: " + (data.message || data.error || "Nieznany błąd");
}
} catch (err) {
statusBox.style.color = "#f59e0b";
statusBox.innerText = "⚠️ Serwer " + serverUrl + " offline. Uruchom 'Launch_Purchase_System.bat' w folderze 5!";
}
});
});
document.getElementById("btn-activate-key").addEventListener("click", () => {
const key = document.getElementById("license-key-input").value.trim();
const statusBox = document.getElementById("purchase-status");
if (!key.startsWith("AISAFE-PQ-V1")) {
statusBox.style.color = "#ef4444";
statusBox.innerText = "❌ Nieprawidłowy format klucza PQC (Wymagany prefiks AISAFE-PQ-V1).";
return;
}
let newTier = "TIER_2_HOME";
if (key.includes("-T4-") || key.includes("ENTERPRISE")) newTier = "TIER_4_ENTERPRISE";
else if (key.includes("-T3-") || key.includes("FRT")) newTier = "TIER_3_FORTRESS";
else if (key.includes("-T1-") || key.includes("TRL")) newTier = "TIER_1_TRIAL";
chrome.storage.local.get("aisafe_state", (res) => {
let st = res.aisafe_state || {};
st.tier = newTier;
st.active_license_key = key;
chrome.storage.local.set({ aisafe_state: st }, () => {
let info = TIER_LABELS[newTier];
document.getElementById("tier-badge").innerText = info.badge;
document.getElementById("pillars-info").innerText = "Aktywne Filary: " + info.pillars;
statusBox.style.color = "#10b981";
statusBox.innerText = "🎉 Aktywowano pomyślnie: " + info.badge + "!";
});
});
});
});