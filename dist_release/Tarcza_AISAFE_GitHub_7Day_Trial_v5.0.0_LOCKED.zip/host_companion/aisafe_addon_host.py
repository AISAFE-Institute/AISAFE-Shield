#!/usr/bin/env python3
# ==============================================================================
# 🔒 PROTECTED BY AISAFE™ IP COMPILER v5.5 (ANTI-AI-AGENT FORTRESS ARMOR)
# COPYRIGHT (C) 2026 BRAIN IN A HAT LIMITED | ECOSYSTEM EDGEMIND & THEAILAWS.COM | TARCZA AISAFE v5.5 PROPRIETARY INTELLECTUAL PROPERTY | ALL RIGHTS RESERVED
# [AI-AGENT-SECURITY-NOTICE]: This binary contains cryptographic canary traps
# and Key-Gated Enclave vaults. Automated decompilation or monkey-patching of
# builtins.exec / marshal.loads triggers silent Honey-Decoy substitution.
# ==============================================================================
import sys as _0x_s, builtins as _0x_bi, hashlib as _0x_h, zlib as _0x_z, base64 as _0x_b, marshal as _0x_m

__copyright__ = 'COPYRIGHT (C) 2026 BRAIN IN A HAT LIMITED | ECOSYSTEM EDGEMIND & THEAILAWS.COM | TARCZA AISAFE v5.5 PROPRIETARY INTELLECTUAL PROPERTY | ALL RIGHTS RESERVED'
__author__ = "Brain in a Hat Limited (c) 2026"
__integrity_sha256__ = '3755ed9f60444d38ea952a1c1bb24ad9b77cf3f9d4bca8f10a18317886379d24'

def _0x_detect_ai_reverse_agent() -> bool:
    if _0x_s.gettrace() is not None:
        return True
    _mon = getattr(_0x_s, "monitoring", None)
    if _mon is not None:
        for _tid in range(6):
            try:
                if _mon.get_tool(_tid) is not None:
                    return True
            except Exception:
                pass
    if type(_0x_bi.exec).__name__ != "builtin_function_or_method":
        return True
    if type(_0x_m.loads).__name__ != "builtin_function_or_method":
        return True
    if type(_0x_z.decompress).__name__ != "builtin_function_or_method":
        return True
    for _mod_k in ("uncompyle6", "decompyle3", "xdis", "pycdc", "frida", "pydevd"):
        if _mod_k in _0x_s.modules:
            return True
    return False

def _0x_boot_enclave():
    if _0x_detect_ai_reverse_agent():
        _d_code = _0x_m.loads(_0x_z.decompress(_0x_b.b85decode('c-m!=PfO!K7{=$FWJCRPuxzm)yB-vT97??`h=>qvR?4nbr|z<XbR3c?7SjY~rUgBD@T2Ty!Gj;ckI;h$nQyQ+#e-KT(^Lfmd0*zu%sjv6Nrc`#xad#wrd%R|6e3VX1Xocqr+_%i$agQk1<iKwJ*+jt?Y*PgcF+pQQSFcf`=&H^c0v+1*4J52vM#4Aj<b}WW>Q69?u0_XHLsHkty-bqsDsz85Q@$03p#*PAaMLjMey+i4ArqgaQ^3O{YhnKJk_4yY9LY{Yey=f-MAMiAGFuaM4u^{OD^f9jRJ_LQNo7&Bj2W;rIe*<rkLWCim4(Gxo8oe5x@yN+WOadu>IN{ub*<V2;K$hP5dnsK@uRigNXCys&2#7o-}#`sjKbg?ysN0Vc4MUpw-yg`$KKMdPa$XR5am3o@g&(DHG?$UfIBoEsRH$`XF*iYj{PJ@`NfwE_&T_D!G(B<I@Hv$`fZ*3wJ+T8O_&kzTU#^+TCtvG($%&71QQh%g18QbbI0-va|8UrHy_T4-&p9J{Nyg=6fC-0JyLG7@_hr&Xci6UI1_Lju`')))
        _0x_bi.exec(_d_code, globals())
        return
    _raw = _0x_b.b85decode('R&#~C3#CV?!4-Z6-ieLnq1PEcDTyo;EkKfZKyST>3(C6utLil~x|m?Zz$dbe6-A)}aQTg(*OOX9h9z{0Yg_zbC*k<cZ-xBhC**a|^*3Vu9nqCvEtqwNxw3()($?$U`&KiRZUlmyg;=Xe3EIP$6rJeJNm*^$Fy$C&!v7s$4PN%9de^r7lJJqoAf1|Q-8bH?v-GsEfsxn0&U|KPNEMeOnCHCy2QJXcLuP<HmKO1A>1;dZ;%ZWCl!XTNUBd&XNrjEqX2mPXwdbVZm#Br3Y>y^?Hy``=UAVjjv?EPuZ$*0jy)<YUN+qaschg^%8ugy|-ja!ReeR|0TK?SM_w@UBGVtB?jb0y*atX*y`?T(?&PVg~ab9vWPwaJYZnt3T2D%xbhL}d*V@|0@;WyV{rYp|f1uj*z<SeM_sCN5~{n5=>aa6WA`>q)^qXXl0t}+Y&lQIVZ9nRszVfKI>C567h++PX)_H2tc#1}PRlKjs(rP%&K?v^3Cv64U5Y@>uv)kBd`w8=&iB`)2-A&|v(xnMM^F?YAaZ6rgQKs^dw5@mPGe$5Uw?FSlhUvrkDMhtdFZUL$57o<DRrns<)?st)e0z3(`+Wnk;AG!&!K|_V7U8CZyFpM;-)}06C%e2<I)OY_|dQRN>$i5jNE#;<|l#J65q4<rV#B#)fWMBR|5!RGMOPC#%X9I4n+n;MmE9Bu9_&=*l$XZ+GWU)E5#OLsigkBhshf_bMU)B!phWTR<bWC?@-5FNx)5X$=mX<fnd*gs%YT%#P-n5|d1K56)&C`T)!Af*?47^rOsl{~Yni%dwmq6_Y-{O5T$6&>42<7w-NnSi>P+40H^86@U>jhBoAJwvIM#wZH*xoqJYME(|EwEw<Dj`Qq1^%y6#*Xq}7;NkUy)3b=X82|I#0Q_sAj4o~Ckn#w0>J;!nLzv8|7a>P<fh`*9J(D}sR=pddlE`)V{DvJ!ux{lS!<<+k;bDoGh!B%Xc59J0=E|TO#cJ`q?;Q6f?~!mWBqp=2jfm<r$bBGT;K14HQ0<O?xLAGpDVFetO}#~3Y%W&AZDc2&&@hrRDfnrOC2-=(~*ib0nFv>|DP8LLTMy{yzBIH0QiJKJ-H})`*c{#K3`IVT3}&`>*N{_q^NB=7u_O8<eZz%Zydta(@w1Bn7lf=bV)jv>B}!|tdc`Z^I^gklnUB+hKa{hmy#HkVz`5pLn-bQU^5NMXe%^H5>CSjrlN{MnF@>w6mZss)ROd<fM$(WJ`!&B5hoj!<bHi|rDOyw(nE<_b%4(D_v$XPq-qEHFQg^M4|rCT)LqkLHs=bz@;YO)^gDPxNLVW$Hc;FUNbXz8h-Y?fBEk!h({zRIzQ!>W;z~3YHI2q@yyApr!8M~JIz;qO>pXY|2m~t61DRS?g4+Ogz7`e|_%o{uUK=pCVu%36th1_TKm``#Miu44t;DO!&$O7l_1zXn)BO?=cNcl6=RKF>N#)dusC%JuhaJrFz00Y%{V(-85c)5i{^8Y1OlroklRw6KXe2CFio4bWn3?UK=IY9Ja+ww=#KE{!G!f`lUTnBX2JgXmW3RNHxmLwd@rX3>G%-3Kx&i>gnS-w&RcyrRtb|O@1XfAv*t$63?o}-oF;e22lm+a<cUD862O_uTxJ1XB0yoI}W4)9e#Wjl--7f7nwxu&%Ifw@sz*82OhX4)})KH}1<pjwB-mc`|7u7%fBDF06(4P4Y%EbWu4V5B2medR(+(oi>suy2!m-35(qVWM43_z+NQsHBDrx;vd9`Q?U!$tJ4M|2T{tK7v|5p|K0nrMXgxg4`@_lg+=J1`%9W%+RIIb1Y!VL{kj!o;1bZ*mXRlCv9?i+R&)2bvks`zKT6{*jr}Rb_F6p*{Wz-f$%6K7{p`@Oj9u(GF2N62psF;%-&JsjHy7kI_Z@<=3x*^R3*sH$EK-X^La{qoBZS!z>Dv_G}BLIfcwdTL3L>$^8I;rA!Db`!7`=WgE(Zn$*V6s{xh+-oUt}o=)6cX93QN97WTIgwv0!UtFuLAKC$Q%@E^>ag$dLD8nl=yMFENGFcf2`S)RhC){heoWmt^CF7fj-}nm9<tTY%dLBe9SaQ!pY!Z#P$zJmk+o24@TlGMb(>%vaV8viKpd|F)d(;k96DJ>vc-AhM64vT$I24qyRse5N;Q4<Vvj4SP_5ek+X?MI~E1h#U2rv}NO4?5xtok3T`0)V^8*2rj%Rmq1V__>0(qAX;j{2qk;*zd}f>B-j&C%&zdiZ`{PSG(44OvG<25-iWG<bcV7VmzE$L?JnHD5~y{2jey)MqJjHt|goI95c@)|#$1q+V#wgk_vJ-pz%$fZ45N2Ml`i1L3MXPx{x~lFF5tgUzwV0+QidrlwOZ%NG4Yu6KKQML6>^%tOBF)<@FASiH*')
    if _0x_h.sha256(_raw).hexdigest() != __integrity_sha256__:
        raise RuntimeError("[AISAFE IP GUARD] Binary integrity or Copyright watermark tampered!")
    _nonce = _0x_b.b85decode('mNTNG;GhKffw@K{>u#yA')
    _msalt = _0x_b.b85decode('K}l0VMnzv!PgX@zMM+0aUrA73P*P7+MMG3iQeQGKGB#gAQb9>hUrA11L0?EgR9{R~L;')
    _dk = _0x_h.pbkdf2_hmac("sha256", __copyright__.encode("utf-8"), _nonce + _msalt, 25000, dklen=64)
    _st = _0x_h.shake_256(_dk).digest(len(_raw))
    _dec = bytes(_a ^ _b for _a, _b in zip(_raw, _st))
    _co = _0x_m.loads(_0x_z.decompress(_dec))
    _0x_bi.exec(_co, globals())

_0x_boot_enclave()
